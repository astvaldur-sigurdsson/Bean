"""Pygbag entry � Classic with sound."""
import asyncio
import sys
import traceback


def jslog(msg):
    try:
        import platform
        platform.window.console.log("[BEAN] " + str(msg))
    except Exception:
        print("[BEAN]", msg)


async def _runner():
    jslog("main.py: _runner start")
    try:
        import pygame
        jslog(f"main.py: pygame {pygame.version.ver}")
        from slot_megaways import main as game_main
        await game_main()
    except BaseException as e:
        tb = traceback.format_exc()
        jslog("FATAL: " + repr(e))
        for line in tb.splitlines():
            jslog(line)
        print(tb, file=sys.stderr)
        while True:
            await asyncio.sleep(1)


asyncio.run(_runner())
