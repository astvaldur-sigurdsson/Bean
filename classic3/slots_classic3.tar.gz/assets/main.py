"""Pygbag entry � Classic 3x3."""
import asyncio, sys, traceback
def jslog(msg):
    try:
        import platform
        platform.window.console.log("[BEAN] " + str(msg))
    except Exception:
        print("[BEAN]", msg)
async def _runner():
    try:
        import pygame
        jslog(f"pygame {pygame.version.ver}")
        from slot_classic3 import main
        await main()
    except BaseException as e:
        tb = traceback.format_exc()
        jslog("FATAL: " + repr(e))
        for line in tb.splitlines(): jslog(line)
        print(tb, file=sys.stderr)
        while True: await asyncio.sleep(1)
asyncio.run(_runner())
