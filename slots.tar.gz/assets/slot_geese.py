"""Goose variant of the Megaways slot — same math, different high symbols.

Run:    python slot_geese.py
"""
import os
import asyncio

os.environ["SLOT_ICONS_DIR"] = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "icons_geese"
)

from slot_megaways import main  # noqa: E402

if __name__ == "__main__":
    asyncio.run(main())
