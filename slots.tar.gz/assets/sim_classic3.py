"""Monte Carlo RTP simulation for slot_classic3."""
import random
import sys
sys.path.insert(0, '.')
from slot_classic3 import spin_grid, evaluate, BET

N = 500_000
rng = random.Random(0)
total_bet = N * BET
total_pay = 0.0
wins = 0
for _ in range(N):
    g = spin_grid(rng)
    _, pay = evaluate(g, BET)
    total_pay += pay
    if pay > 0:
        wins += 1
print(f"spins:    {N:,}")
print(f"hit rate: {wins/N*100:.2f}%")
print(f"RTP:      {total_pay/total_bet*100:.2f}%")
