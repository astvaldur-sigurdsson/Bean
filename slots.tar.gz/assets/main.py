"""Pygbag entry point — just runs the game."""
import asyncio
import traceback


async def _runner():
    try:
        from slot_megaways import main
        await main()
    except Exception:
        traceback.print_exc()
        # keep terminal visible so user can read the traceback
        while True:
            await asyncio.sleep(1)


asyncio.run(_runner())
