"""Pygbag entry point with verbose JS-console logging for diagnosis."""
import asyncio
import sys
import traceback


def jslog(msg):
    try:
        import platform
        platform.window.console.log("[BEAN] " + str(msg))
    except Exception:
        print("[BEAN]", msg)


async def _runner():
    jslog("main.py: _runner start")
    try:
        jslog("main.py: importing pygame")
        import pygame
        jslog(f"main.py: pygame {pygame.version.ver}")
        jslog("main.py: importing slot_megaways")
        from slot_megaways import main as game_main
        jslog("main.py: calling game_main()")
        await game_main()
        jslog("main.py: game_main returned")
    except BaseException as e:
        tb = traceback.format_exc()
        jslog("FATAL: " + repr(e))
        for line in tb.splitlines():
            jslog(line)
        print(tb, file=sys.stderr)
        while True:
            await asyncio.sleep(1)


asyncio.run(_runner())
