"""Generate slot SFX as WAV files using only stdlib (wave + math).

Outputs go to sounds/ as 16-bit mono 22050 Hz WAVs.
Run: python make_sounds.py
"""
from __future__ import annotations
import math
import os
import random
import struct
import wave

HERE = os.path.dirname(os.path.abspath(__file__))
DST = os.path.join(HERE, "sounds")
os.makedirs(DST, exist_ok=True)

SR = 11025  # sample rate (low rate keeps file size small; fine for short SFX)


def _write(name: str, samples: list[float]) -> None:
    # clip and convert to int16
    path = os.path.join(DST, name)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        frames = bytearray()
        for s in samples:
            v = max(-1.0, min(1.0, s))
            frames += struct.pack("<h", int(v * 32760))
        w.writeframes(bytes(frames))
    print(f"wrote {path}  ({len(samples)/SR:.2f}s)")


def env(t: float, attack: float, decay: float, total: float) -> float:
    if t < attack:
        return t / attack
    if t < total - decay:
        return 1.0
    if t < total:
        return max(0.0, (total - t) / decay)
    return 0.0


def sine(freq: float, dur: float, vol: float = 0.5,
         attack: float = 0.005, decay: float = 0.05) -> list[float]:
    n = int(dur * SR)
    return [vol * env(i / SR, attack, decay, dur) *
            math.sin(2 * math.pi * freq * (i / SR)) for i in range(n)]


def square(freq: float, dur: float, vol: float = 0.3,
           attack: float = 0.005, decay: float = 0.05) -> list[float]:
    n = int(dur * SR)
    out = []
    for i in range(n):
        t = i / SR
        s = 1.0 if math.sin(2 * math.pi * freq * t) >= 0 else -1.0
        out.append(vol * env(t, attack, decay, dur) * s)
    return out


def noise(dur: float, vol: float = 0.3,
          attack: float = 0.005, decay: float = 0.1) -> list[float]:
    n = int(dur * SR)
    rng = random.Random(42)
    return [vol * env(i / SR, attack, decay, dur) * (rng.random() * 2 - 1)
            for i in range(n)]


def mix(*tracks: list[float]) -> list[float]:
    n = max(len(t) for t in tracks)
    out = [0.0] * n
    for t in tracks:
        for i, v in enumerate(t):
            out[i] += v
    return out


def offset(samples: list[float], delay: float) -> list[float]:
    pad = [0.0] * int(delay * SR)
    return pad + samples


# ----- individual sounds ----------------------------------------------------

def click() -> list[float]:
    # short button click
    return mix(
        sine(880, 0.04, vol=0.4, attack=0.001, decay=0.03),
        noise(0.02, vol=0.15, attack=0.001, decay=0.015),
    )


def spin_start() -> list[float]:
    # rising whoosh
    n = int(0.35 * SR)
    out = []
    for i in range(n):
        t = i / SR
        f = 200 + 600 * (t / 0.35)
        e = env(t, 0.02, 0.1, 0.35)
        out.append(0.35 * e * math.sin(2 * math.pi * f * t))
    # add a little noise
    return mix(out, noise(0.35, vol=0.08, attack=0.02, decay=0.1))


def reel_stop() -> list[float]:
    # short thump: low pop + tiny click
    n = int(0.12 * SR)
    out = []
    for i in range(n):
        t = i / SR
        f = 180 - 120 * (t / 0.12)  # pitch drop
        e = env(t, 0.002, 0.08, 0.12)
        out.append(0.5 * e * math.sin(2 * math.pi * f * t))
    return mix(out, noise(0.04, vol=0.2, attack=0.001, decay=0.03))


def win_small() -> list[float]:
    # cheerful 3-note arpeggio C E G
    a = sine(523, 0.10, vol=0.35)
    b = offset(sine(659, 0.10, vol=0.35), 0.08)
    c = offset(sine(784, 0.18, vol=0.35), 0.16)
    return mix(a, b, c)


def win_big() -> list[float]:
    # longer ascending arpeggio + sparkle
    notes = [523, 659, 784, 988, 1175]  # C E G B D'
    parts = []
    for i, f in enumerate(notes):
        parts.append(offset(sine(f, 0.18, vol=0.3, decay=0.15), i * 0.10))
    sparkle = []
    for i in range(8):
        sparkle.append(offset(sine(1500 + i * 130, 0.06, vol=0.12),
                              0.50 + i * 0.04))
    return mix(*parts, *sparkle)


def scatter() -> list[float]:
    # mystical descending then rising bell
    a = sine(880, 0.20, vol=0.3, decay=0.18)
    b = offset(sine(660, 0.20, vol=0.3, decay=0.18), 0.10)
    c = offset(sine(1320, 0.40, vol=0.4, decay=0.35), 0.25)
    return mix(a, b, c)


def fs_trigger() -> list[float]:
    # fanfare: 2 quick rising lines then long chord
    parts = [
        sine(523, 0.10, vol=0.3),
        offset(sine(784, 0.10, vol=0.3), 0.08),
        offset(sine(1047, 0.10, vol=0.3), 0.16),
        offset(sine(523, 0.50, vol=0.25, decay=0.4), 0.30),
        offset(sine(659, 0.50, vol=0.25, decay=0.4), 0.30),
        offset(sine(784, 0.50, vol=0.25, decay=0.4), 0.30),
        offset(sine(1047, 0.50, vol=0.25, decay=0.4), 0.30),
    ]
    return mix(*parts)


def bust() -> list[float]:
    # sad descending
    parts = [
        sine(440, 0.18, vol=0.3, decay=0.12),
        offset(sine(370, 0.18, vol=0.3, decay=0.12), 0.16),
        offset(sine(294, 0.30, vol=0.3, decay=0.25), 0.32),
    ]
    return mix(*parts)


SOUNDS = {
    "click.wav": click,
    "spin.wav": spin_start,
    "reel_stop.wav": reel_stop,
    "win_small.wav": win_small,
    "win_big.wav": win_big,
    "scatter.wav": scatter,
    "fs_trigger.wav": fs_trigger,
    "bust.wav": bust,
}


def main() -> None:
    for name, fn in SOUNDS.items():
        _write(name, fn())


if __name__ == "__main__":
    main()
