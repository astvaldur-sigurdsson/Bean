"""Old-school 3x3 fruit-machine slot with a pull lever and 5 paylines.

Run:    python slot_classic3.py
Icons:  PNGs in icons_classic3/ (override with SLOT_ICONS_DIR env var).
"""
from __future__ import annotations

import asyncio
import math
import os
import random
import sys
from dataclasses import dataclass
from typing import Optional

import pygame

# ---------------------------------------------------------------------------
# Game config
# ---------------------------------------------------------------------------

REELS = 3
ROWS = 3
BET = 1.0
BET_SIZES = [0.10, 0.50, 1.00, 5.00, 25.00]
STARTING_BALANCE = 1000.0

# (key, weight, payouts {3: mult_of_bet})
# Tuned roughly toward ~95% RTP across 5 paylines.
SYMBOLS = [
    ("cherry",  20, {2: 0.42, 3: 2.1}),
    ("lemon",   16, {3: 3.3}),
    ("orange",  14, {3: 4.2}),
    ("bell",    10, {3: 8.4}),
    ("bar1",     7, {3: 16.0}),
    ("bar2",     5, {3: 31.0}),
    ("bar3",     3, {3: 61.0}),
    ("diamond",  3, {3: 84.0}),
    ("seven",    2, {3: 205.0}),
]
WILD = "wild"
WILD_WEIGHT = 1   # rare; substitutes for any symbol

# 5 paylines on 3x3 (row indices per reel):
PAYLINES = [
    (1, 1, 1),  # middle row
    (0, 0, 0),  # top row
    (2, 2, 2),  # bottom row
    (0, 1, 2),  # diagonal \
    (2, 1, 0),  # diagonal /
]

# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

WIDTH, HEIGHT = 960, 720
CABINET_RECT = pygame.Rect(80, 60, 800, 600)
REEL_AREA = pygame.Rect(180, 200, 540, 360)
CELL = 180
CELL_PAD = 8

LEVER_X = 870
LEVER_TOP = 200
LEVER_LEN = 180

BG = (30, 18, 12)
CABINET = (170, 30, 30)
CABINET_TRIM = (240, 200, 60)
PANEL = (245, 240, 220)
PANEL_DK = (200, 190, 160)
TEXT = (50, 30, 20)
WIN_GLOW = (255, 220, 80)


# ---------------------------------------------------------------------------
# Math
# ---------------------------------------------------------------------------

def build_pool() -> list[str]:
    pool = []
    for key, w, _ in SYMBOLS:
        pool += [key] * w
    pool += [WILD] * WILD_WEIGHT
    return pool


def spin_grid(rng: random.Random) -> list[list[str]]:
    pool = build_pool()
    return [[rng.choice(pool) for _ in range(ROWS)] for _ in range(REELS)]


@dataclass
class LineWin:
    line_idx: int
    symbol: str
    count: int
    pay: float
    cells: list[tuple[int, int]]  # (reel, row)


def evaluate(grid: list[list[str]], bet: float) -> tuple[list[LineWin], float]:
    wins: list[LineWin] = []
    total = 0.0
    for li, line in enumerate(PAYLINES):
        # symbols on this line per reel
        line_syms = [grid[r][line[r]] for r in range(REELS)]
        # decide payout symbol: the first non-wild (wild matches anything)
        # For 3-reel, rule: count consecutive matches from left of any specific symbol
        # using wild as substitute.
        # Easier: try each candidate symbol = first non-wild on line; if all wild,
        # use most valuable.
        non_wild = [s for s in line_syms if s != WILD]
        if not non_wild:
            cand = "seven"  # all wilds -> top symbol
        else:
            cand = non_wild[0]
            if any(s != cand and s != WILD for s in non_wild):
                # not a single symbol type across line; check left-to-right run
                cand = line_syms[0] if line_syms[0] != WILD else line_syms[1]

        # count consecutive from left
        count = 0
        for r in range(REELS):
            if line_syms[r] == cand or line_syms[r] == WILD:
                count += 1
            else:
                break

        # find payout from symbol table
        table = next((tbl for k, _, tbl in SYMBOLS if k == cand), None)
        if table is None:
            continue
        if count not in table:
            continue
        pay = table[count] * bet
        cells = [(r, line[r]) for r in range(count)]
        wins.append(LineWin(li, cand, count, pay, cells))
        total += pay
    return wins, total


# ---------------------------------------------------------------------------
# Assets
# ---------------------------------------------------------------------------

class Assets:
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.icons: dict[str, pygame.Surface] = {}

        def _font(name: str, size: int, bold: bool = False) -> pygame.font.Font:
            try:
                f = pygame.font.SysFont(name, size, bold=bold)
                if f is not None:
                    return f
            except Exception:
                pass
            return pygame.font.Font(None, size)

        self.font_xl = _font("georgia", 56, bold=True)
        self.font_lg = _font("georgia", 36, bold=True)
        self.font_md = _font("georgia", 24, bold=True)
        self.font_sm = _font("georgia", 18)

    def load_icons(self):
        icons_dir = os.environ.get("SLOT_ICONS_DIR") or \
            os.path.join(self.base_dir, "icons_classic3")
        size = CELL - CELL_PAD * 2
        keys = [k for k, _, _ in SYMBOLS] + [WILD]
        loaded = 0
        for key in keys:
            path = os.path.join(icons_dir, f"{key}.png")
            try:
                img = pygame.image.load(path).convert_alpha()
                img = pygame.transform.smoothscale(img, (size, size))
                self.icons[key] = img
                loaded += 1
            except Exception as e:
                print(f"icon load failed for {key}: {e}", flush=True)
                surf = pygame.Surface((size, size), pygame.SRCALPHA)
                pygame.draw.rect(surf, (200, 200, 200), surf.get_rect(),
                                 border_radius=12)
                self.icons[key] = surf
        print(f"icons: {loaded}/{len(keys)} loaded", flush=True)


# ---------------------------------------------------------------------------
# Spin animation
# ---------------------------------------------------------------------------

class SpinAnimation:
    REEL_DURATIONS = [0.45, 0.75, 1.05]

    def __init__(self, final_grid: list[list[str]], assets: Assets):
        self.grid = final_grid
        self.assets = assets
        self.elapsed = 0.0
        self.fake_pool = [k for k, _, _ in SYMBOLS] + [WILD]

    def update(self, dt: float) -> bool:
        self.elapsed += dt
        return self.elapsed >= max(self.REEL_DURATIONS) + 0.05

    def display_grid(self) -> list[list[str]]:
        out = []
        for r in range(REELS):
            if self.elapsed >= self.REEL_DURATIONS[r]:
                out.append(self.grid[r])
            else:
                out.append([random.choice(self.fake_pool) for _ in range(ROWS)])
        return out


# ---------------------------------------------------------------------------
# Game
# ---------------------------------------------------------------------------

class SlotGame:
    def __init__(self):
        pygame.init()
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
        except Exception:
            pass
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Classic 3x3 Slot")
        self.clock = pygame.time.Clock()
        self.assets = Assets(os.path.dirname(os.path.abspath(__file__)))
        self.assets.load_icons()
        self.rng = random.Random()

        self.bet = BET
        self.balance = STARTING_BALANCE
        self.last_grid: list[list[str]] = [[k for k, _, _ in SYMBOLS][:ROWS]
                                           for _ in range(REELS)]
        self.last_wins: list[LineWin] = []
        self.last_pay = 0.0
        self.spins = 0
        self.biggest_win = 0.0
        self.message = "Pull the lever!"

        self.spin_anim: Optional[SpinAnimation] = None
        # lever animation: 0..1 pulled angle factor, returns to 0
        self.lever_t = 0.0  # 0 = up, 1 = fully pulled
        self.lever_target = 0.0
        self.win_flash_t = 0.0  # for win glow
        self.shown_winline = 0  # cycle through wins for highlighting

    # ----- input -----
    async def run(self):
        running = True
        while running:
            dt = self.clock.tick(60) / 1000.0
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    running = False
                elif ev.type == pygame.KEYDOWN:
                    if ev.key in (pygame.K_SPACE, pygame.K_RETURN):
                        self.try_spin()
                    elif ev.key == pygame.K_ESCAPE:
                        running = False
                    elif pygame.K_1 <= ev.key <= pygame.K_5:
                        self._set_bet_index(ev.key - pygame.K_1)
                elif ev.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = ev.pos
                    handled = False
                    for i in range(len(BET_SIZES)):
                        if self._bet_button_rect(i).collidepoint(mx, my):
                            self._set_bet_index(i)
                            handled = True
                            break
                    if handled:
                        pass
                    elif self._lever_hitbox().collidepoint(mx, my):
                        self.try_spin()
                    elif self._spin_button_rect().collidepoint(mx, my):
                        self.try_spin()
            self.update(dt)
            self.draw()
            pygame.display.flip()
            await asyncio.sleep(0)
        pygame.quit()

    def try_spin(self):
        if self.spin_anim is not None:
            return
        if self.balance < self.bet:
            self.message = "Out of balance"
            return
        self.balance -= self.bet
        self.spins += 1
        grid = spin_grid(self.rng)
        self.spin_anim = SpinAnimation(grid, self.assets)
        self.lever_target = 1.0  # pull lever down

    def resolve_spin(self, grid: list[list[str]]):
        wins, pay = evaluate(grid, self.bet)
        self.balance += pay
        self.last_grid = grid
        self.last_wins = wins
        self.last_pay = pay
        if pay > self.biggest_win:
            self.biggest_win = pay
        if pay > 0:
            self.message = f"WIN  ${pay:,.2f}"
            self.win_flash_t = 1.0
        else:
            self.message = "No win"

    def update(self, dt: float):
        # animate lever toward target
        speed = 6.0
        if self.lever_t < self.lever_target:
            self.lever_t = min(self.lever_target, self.lever_t + speed * dt)
        elif self.lever_t > self.lever_target:
            self.lever_t = max(self.lever_target, self.lever_t - speed * 0.6 * dt)
        # release lever shortly after pull
        if self.lever_t >= 0.95 and self.lever_target == 1.0:
            self.lever_target = 0.0

        if self.win_flash_t > 0:
            self.win_flash_t = max(0.0, self.win_flash_t - dt * 0.6)
            # cycle highlighted line every 0.6s
            self.shown_winline = int((1.0 - self.win_flash_t) / 0.6) % \
                                 max(1, len(self.last_wins) or 1)

        if self.spin_anim is not None:
            done = self.spin_anim.update(dt)
            if done:
                grid = self.spin_anim.grid
                self.spin_anim = None
                self.resolve_spin(grid)

    # ----- draw -----
    def draw(self):
        self.screen.fill(BG)
        self._draw_cabinet()
        self._draw_marquee()
        self._draw_reels()
        self._draw_paylines_overlay()
        self._draw_lever()
        self._draw_panel()

    def _draw_cabinet(self):
        # outer cabinet
        pygame.draw.rect(self.screen, CABINET, CABINET_RECT, border_radius=24)
        pygame.draw.rect(self.screen, CABINET_TRIM, CABINET_RECT, width=6,
                         border_radius=24)
        # decorative bulb dots around top
        for i in range(12):
            x = CABINET_RECT.x + 30 + i * (CABINET_RECT.w - 60) / 11
            y = CABINET_RECT.y + 20
            blink = (math.sin(pygame.time.get_ticks() / 200 + i) + 1) / 2
            color = (255, int(180 + 60 * blink), int(60 + 40 * blink))
            pygame.draw.circle(self.screen, color, (int(x), int(y)), 7)
            pygame.draw.circle(self.screen, (60, 30, 10), (int(x), int(y)), 7, 1)

    def _draw_marquee(self):
        rect = pygame.Rect(CABINET_RECT.x + 50, CABINET_RECT.y + 50,
                           CABINET_RECT.w - 100, 90)
        pygame.draw.rect(self.screen, (30, 18, 12), rect, border_radius=14)
        pygame.draw.rect(self.screen, CABINET_TRIM, rect, width=4,
                         border_radius=14)
        title = self.assets.font_xl.render("LUCKY  3x3", True, CABINET_TRIM)
        self.screen.blit(title, title.get_rect(center=rect.center))

    def _draw_reels(self):
        # window background panel
        win_rect = REEL_AREA.inflate(20, 20)
        pygame.draw.rect(self.screen, (15, 10, 8), win_rect, border_radius=12)
        pygame.draw.rect(self.screen, CABINET_TRIM, win_rect, width=4,
                         border_radius=12)

        grid = self.spin_anim.display_grid() if self.spin_anim else self.last_grid
        win_cells = self._winning_cells()

        for r in range(REELS):
            for row in range(ROWS):
                cx = REEL_AREA.x + r * CELL + CELL // 2
                cy = REEL_AREA.y + row * (CELL - 60) + (CELL - 60) // 2 + 10
                self._draw_cell(grid[r][row], cx, cy, (r, row) in win_cells)

    def _draw_cell(self, sym: str, cx: int, cy: int, highlight: bool):
        size = CELL - CELL_PAD * 2
        # cell tile background
        rect = pygame.Rect(cx - size // 2, cy - size // 2 + 30, size, size - 60)
        pygame.draw.rect(self.screen, PANEL, rect, border_radius=10)
        pygame.draw.rect(self.screen, PANEL_DK, rect, width=2, border_radius=10)

        icon = self.assets.icons.get(sym)
        if icon is not None:
            # scale to fit cell rect
            target_h = rect.h - 12
            scale = target_h / icon.get_height()
            new_w = int(icon.get_width() * scale)
            scaled = pygame.transform.smoothscale(icon, (new_w, target_h))
            self.screen.blit(scaled, scaled.get_rect(center=rect.center))

        if highlight:
            glow = (int(255 * (0.5 + 0.5 * math.sin(pygame.time.get_ticks() / 120))),
                    220, 80)
            pygame.draw.rect(self.screen, glow, rect, width=4, border_radius=10)

    def _winning_cells(self) -> set[tuple[int, int]]:
        if not self.last_wins or self.spin_anim is not None:
            return set()
        if self.win_flash_t <= 0:
            # show all wins steadily after flash ends
            cells = set()
            for w in self.last_wins:
                cells.update(w.cells)
            return cells
        # flash one line at a time
        idx = self.shown_winline % len(self.last_wins)
        return set(self.last_wins[idx].cells)

    def _draw_paylines_overlay(self):
        # draw small dots in left margin showing the 5 lines
        x = REEL_AREA.x - 28
        for li, line in enumerate(PAYLINES):
            for r in range(REELS):
                row = line[r]
                cy = REEL_AREA.y + row * (CELL - 60) + (CELL - 60) // 2 + 40
                color = (255, 200, 80) if any(w.line_idx == li for w in self.last_wins) \
                    else (140, 100, 80)
                pygame.draw.circle(self.screen, color,
                                   (x - r * 6, cy + (li - 2) * 4), 3)

    def _draw_lever(self):
        # lever base (cylinder)
        base_x = LEVER_X
        base_y = LEVER_TOP + LEVER_LEN
        pygame.draw.rect(self.screen, (90, 80, 90),
                         (base_x - 22, base_y - 30, 44, 60), border_radius=6)
        pygame.draw.rect(self.screen, (30, 25, 30),
                         (base_x - 22, base_y - 30, 44, 60), width=2,
                         border_radius=6)

        # lever arm: rotates from vertical (lever_t=0) to ~70deg (t=1)
        angle = math.radians(0 + 75 * self.lever_t)
        # base at (base_x, base_y), tip extends UP-then-FORWARD as it rotates
        length = LEVER_LEN
        tip_x = base_x + math.sin(angle) * length
        tip_y = base_y - math.cos(angle) * length

        pygame.draw.line(self.screen, (180, 180, 200),
                         (base_x, base_y), (int(tip_x), int(tip_y)), 10)
        pygame.draw.line(self.screen, (220, 220, 240),
                         (base_x, base_y), (int(tip_x), int(tip_y)), 4)
        # red knob
        pygame.draw.circle(self.screen, (210, 40, 40),
                           (int(tip_x), int(tip_y)), 22)
        pygame.draw.circle(self.screen, (255, 120, 120),
                           (int(tip_x - 6), int(tip_y - 6)), 8)
        pygame.draw.circle(self.screen, (40, 20, 20),
                           (int(tip_x), int(tip_y)), 22, 2)

    def _lever_hitbox(self) -> pygame.Rect:
        return pygame.Rect(LEVER_X - 30, LEVER_TOP - 20, 80, LEVER_LEN + 60)

    def _spin_button_rect(self) -> pygame.Rect:
        return pygame.Rect(WIDTH // 2 - 90, HEIGHT - 80, 180, 56)

    def _set_bet_index(self, idx: int):
        if self.spin_anim is not None:
            return
        idx = max(0, min(len(BET_SIZES) - 1, idx))
        self.bet = BET_SIZES[idx]

    def _bet_button_rect(self, idx: int) -> pygame.Rect:
        w, h, gap = 70, 28, 6
        total_w = len(BET_SIZES) * w + (len(BET_SIZES) - 1) * gap
        x0 = CABINET_RECT.x + 30
        return pygame.Rect(x0 + idx * (w + gap), CABINET_RECT.bottom - 18, w, h)

    def _draw_panel(self):
        # bottom info panel
        rect = pygame.Rect(CABINET_RECT.x + 30, CABINET_RECT.bottom - 80,
                           CABINET_RECT.w - 60, 60)
        pygame.draw.rect(self.screen, (50, 30, 20), rect, border_radius=10)
        pygame.draw.rect(self.screen, CABINET_TRIM, rect, width=3,
                         border_radius=10)

        bal = self.assets.font_md.render(f"Balance ${self.balance:,.2f}",
                                         True, CABINET_TRIM)
        self.screen.blit(bal, (rect.x + 20, rect.y + 18))

        msg = self.assets.font_md.render(self.message, True,
                                         (255, 255, 200))
        self.screen.blit(msg, msg.get_rect(center=rect.center))

        bet_t = self.assets.font_md.render(f"Bet ${self.bet:.2f}", True, CABINET_TRIM)
        self.screen.blit(bet_t, (rect.right - bet_t.get_width() - 20,
                                 rect.y + 18))

        # spin button
        btn = self._spin_button_rect()
        pygame.draw.rect(self.screen, (220, 50, 60), btn, border_radius=14)
        pygame.draw.rect(self.screen, CABINET_TRIM, btn, width=3,
                         border_radius=14)
        bt = self.assets.font_lg.render("SPIN", True, (255, 255, 240))
        self.screen.blit(bt, bt.get_rect(center=btn.center))

        # hint
        hint = self.assets.font_sm.render(
            "SPACE / click lever / SPIN button   |   1-5 = bet size   |   ESC to quit",
            True, (200, 180, 140))
        self.screen.blit(hint, (CABINET_RECT.x + 30, HEIGHT - 22))
        self._draw_bet_buttons()

    def _draw_bet_buttons(self):
        for i, bs in enumerate(BET_SIZES):
            r = self._bet_button_rect(i)
            sel = abs(self.bet - bs) < 1e-6
            disabled = self.spin_anim is not None
            if disabled:
                fill = (60, 40, 30)
                fg = (140, 110, 80)
            elif sel:
                fill = CABINET_TRIM
                fg = (40, 25, 15)
            else:
                fill = (90, 60, 40)
                fg = (250, 230, 180)
            pygame.draw.rect(self.screen, fill, r, border_radius=6)
            pygame.draw.rect(self.screen, (30, 18, 12), r, width=2,
                             border_radius=6)
            label = f"${bs:g}"
            surf = self.assets.font_sm.render(label, True, fg)
            self.screen.blit(surf, surf.get_rect(center=r.center))


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------

async def main():
    await SlotGame().run()


if __name__ == "__main__":
    asyncio.run(main())
