"""Generate 4 cartoon goose PNGs (high_e..h) into icons_geese/.

Each goose is a different breed/color so they're easy to tell apart on the reels.
Also copies the existing low_*, wild, scatter icons across so the game can run
purely from icons_geese/ via SLOT_ICONS_DIR=icons_geese.
"""
from __future__ import annotations
import os
import shutil
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "icons")
DST = os.path.join(HERE, "icons_geese")
os.makedirs(DST, exist_ok=True)

SIZE = 256  # source resolution; pygame will smoothscale down


def _ellipse(draw: ImageDraw.ImageDraw, cx, cy, rx, ry, fill, outline=None, width=2):
    draw.ellipse((cx - rx, cy - ry, cx + rx, cy + ry), fill=fill, outline=outline, width=width)


def draw_goose(
    body_color: tuple[int, int, int],
    head_color: tuple[int, int, int],
    beak_color: tuple[int, int, int],
    bg_color: tuple[int, int, int],
    *,
    cheek_patch: bool = False,
    crest: bool = False,
    accent: tuple[int, int, int] | None = None,
) -> Image.Image:
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # rounded square background
    pad = 6
    d.rounded_rectangle((pad, pad, SIZE - pad, SIZE - pad), radius=28, fill=bg_color + (255,))

    outline = (30, 30, 35)

    # body (oval, tilted)
    body_cx, body_cy = 140, 165
    _ellipse(d, body_cx, body_cy, 78, 56, body_color, outline, 3)

    # tail (small triangle on right back)
    d.polygon([(210, 150), (240, 130), (228, 170)], fill=body_color, outline=outline)

    # wing
    _ellipse(d, 150, 160, 50, 30, tuple(max(0, c - 25) for c in body_color), outline, 2)
    if accent:
        _ellipse(d, 160, 158, 32, 18, accent, None)

    # neck (elongated curve via overlapping ellipses)
    for t in range(0, 10):
        x = 90 - t * 2
        y = 145 - t * 11
        rx = 22 - t // 2
        ry = 18 - t // 2
        _ellipse(d, x, y, rx, ry, head_color, None)

    # head
    head_cx, head_cy = 70, 55
    _ellipse(d, head_cx, head_cy, 30, 28, head_color, outline, 3)

    # cheek patch (Canada goose)
    if cheek_patch:
        _ellipse(d, head_cx - 4, head_cy + 6, 14, 10, (255, 255, 255))

    # crest (tuft on top)
    if crest:
        d.polygon([(head_cx - 10, head_cy - 26), (head_cx, head_cy - 40),
                   (head_cx + 10, head_cy - 26)], fill=accent or head_color, outline=outline)

    # eye
    _ellipse(d, head_cx + 6, head_cy - 4, 4, 4, (20, 20, 20))
    _ellipse(d, head_cx + 7, head_cy - 5, 1, 1, (255, 255, 255))

    # beak
    d.polygon([(head_cx + 22, head_cy - 4), (head_cx + 50, head_cy + 2),
               (head_cx + 22, head_cy + 8)], fill=beak_color, outline=outline)

    # legs
    for lx in (130, 160):
        d.line([(lx, 215), (lx, 240)], fill=beak_color, width=6)
        d.polygon([(lx - 10, 240), (lx + 10, 240), (lx, 248)], fill=beak_color, outline=outline)

    return img


def main():
    # Goose variants ordered by value: green (low) -> blue -> yellow -> red (jackpot)
    variants = {
        # high_e: GREEN goose (lowest of the high tier)
        "high_e": dict(
            body_color=(95, 170, 90),
            head_color=(70, 140, 70),
            beak_color=(240, 170, 50),
            bg_color=(200, 230, 195),
            accent=(140, 200, 130),
        ),
        # high_f: BLUE goose
        "high_f": dict(
            body_color=(80, 130, 210),
            head_color=(55, 95, 175),
            beak_color=(245, 180, 60),
            bg_color=(195, 215, 245),
            accent=(140, 180, 230),
        ),
        # high_g: YELLOW goose
        "high_g": dict(
            body_color=(245, 210, 70),
            head_color=(225, 185, 50),
            beak_color=(230, 130, 40),
            bg_color=(255, 245, 195),
            accent=(255, 230, 120),
        ),
        # high_h: RED goose (jackpot) — fanciest with crest
        "high_h": dict(
            body_color=(220, 60, 60),
            head_color=(190, 40, 45),
            beak_color=(245, 200, 70),
            bg_color=(60, 25, 35),
            crest=True,
            accent=(245, 110, 110),
        ),
    }

    for key, kwargs in variants.items():
        img = draw_goose(**kwargs)
        out = os.path.join(DST, f"{key}.png")
        img.save(out)
        print(f"wrote {out}")

    # copy low_*, wild, scatter so icons_geese/ is self-contained
    if os.path.isdir(SRC):
        for name in os.listdir(SRC):
            if name.startswith("high_"):
                continue
            s = os.path.join(SRC, name)
            d = os.path.join(DST, name)
            if os.path.isfile(s):
                shutil.copy2(s, d)
                print(f"copied {name}")


if __name__ == "__main__":
    main()
