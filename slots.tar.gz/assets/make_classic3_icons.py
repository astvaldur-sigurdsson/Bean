"""Generate classic fruit-machine icons (cherry, lemon, orange, bell, bar,
double-bar, triple-bar, seven, diamond) into icons_classic3/.
"""
from __future__ import annotations
import os
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
DST = os.path.join(HERE, "icons_classic3")
os.makedirs(DST, exist_ok=True)

SIZE = 256
PAD = 12
BG = (245, 240, 220)  # cream
RIM = (60, 40, 25)


def base() -> tuple[Image.Image, ImageDraw.ImageDraw]:
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((PAD, PAD, SIZE - PAD, SIZE - PAD), radius=24,
                        fill=BG, outline=RIM, width=4)
    return img, d


def _font(size: int) -> ImageFont.FreeTypeFont:
    for name in ("ariblk.ttf", "arialbd.ttf", "Arial Bold.ttf", "arial.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            pass
    return ImageFont.load_default()


def cherry() -> Image.Image:
    img, d = base()
    # two red cherries with green stems and a leaf
    # left cherry
    d.ellipse((70, 130, 150, 210), fill=(210, 30, 40), outline=RIM, width=4)
    d.ellipse((85, 145, 105, 165), fill=(245, 120, 130))  # highlight
    # right cherry
    d.ellipse((140, 150, 215, 220), fill=(180, 20, 30), outline=RIM, width=4)
    d.ellipse((155, 165, 175, 185), fill=(235, 110, 120))
    # stems
    d.line([(115, 135), (135, 70), (175, 60)], fill=(80, 130, 50), width=6)
    d.line([(180, 155), (180, 80), (175, 60)], fill=(80, 130, 50), width=6)
    # leaf
    d.polygon([(170, 60), (210, 50), (215, 80), (180, 80)],
              fill=(110, 170, 70), outline=RIM)
    return img


def lemon() -> Image.Image:
    img, d = base()
    d.ellipse((50, 80, 210, 200), fill=(245, 215, 60), outline=RIM, width=4)
    # tip nubs
    d.ellipse((35, 130, 65, 160), fill=(245, 215, 60), outline=RIM, width=3)
    d.ellipse((195, 130, 225, 160), fill=(245, 215, 60), outline=RIM, width=3)
    # highlight
    d.ellipse((75, 95, 115, 125), fill=(255, 240, 140))
    # leaf
    d.polygon([(120, 70), (155, 40), (170, 70), (140, 80)],
              fill=(110, 170, 70), outline=RIM)
    return img


def orange() -> Image.Image:
    img, d = base()
    d.ellipse((50, 70, 215, 220), fill=(245, 145, 40), outline=RIM, width=4)
    d.ellipse((75, 95, 120, 130), fill=(255, 190, 90))
    # leaf
    d.polygon([(120, 60), (160, 30), (175, 65), (140, 75)],
              fill=(80, 140, 50), outline=RIM)
    # stem
    d.rectangle((128, 60, 138, 80), fill=(90, 60, 30))
    return img


def bell() -> Image.Image:
    img, d = base()
    # bell body
    d.polygon([(70, 200), (90, 80), (165, 80), (185, 200)],
              fill=(245, 200, 50), outline=RIM)
    # round top
    d.ellipse((90, 60, 165, 100), fill=(245, 200, 50), outline=RIM, width=4)
    d.ellipse((105, 75, 130, 95), fill=(255, 230, 110))
    # rim
    d.rectangle((60, 195, 195, 215), fill=(220, 170, 30), outline=RIM)
    # clapper
    d.ellipse((118, 215, 138, 235), fill=(160, 110, 20), outline=RIM, width=3)
    return img


def bar(letters: str = "BAR", color=(220, 30, 30)) -> Image.Image:
    img, d = base()
    # red plate
    plate = (40, 90, 220, 170)
    d.rounded_rectangle(plate, radius=14, fill=color, outline=RIM, width=4)
    f = _font(46 if len(letters) <= 3 else 30)
    text = letters
    bbox = d.textbbox((0, 0), text, font=f)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    d.text(((SIZE - tw) // 2, (SIZE - th) // 2 - 4), text,
           fill=(245, 240, 210), font=f, stroke_width=2, stroke_fill=RIM)
    return img


def bar1() -> Image.Image:
    return bar("BAR", color=(200, 30, 30))


def bar2() -> Image.Image:
    img, d = base()
    for i, y in enumerate((60, 140)):
        d.rounded_rectangle((40, y, 220, y + 70), radius=12,
                            fill=(200, 30, 30), outline=RIM, width=4)
    f = _font(28)
    for y in (75, 155):
        bbox = d.textbbox((0, 0), "BAR", font=f)
        tw = bbox[2] - bbox[0]
        d.text(((SIZE - tw) // 2, y + 8), "BAR", fill=(245, 240, 210), font=f,
               stroke_width=2, stroke_fill=RIM)
    return img


def bar3() -> Image.Image:
    img, d = base()
    for y in (45, 110, 175):
        d.rounded_rectangle((40, y, 220, y + 50), radius=10,
                            fill=(200, 30, 30), outline=RIM, width=3)
    f = _font(22)
    for y in (52, 117, 182):
        bbox = d.textbbox((0, 0), "BAR", font=f)
        tw = bbox[2] - bbox[0]
        d.text(((SIZE - tw) // 2, y + 6), "BAR", fill=(245, 240, 210), font=f,
               stroke_width=2, stroke_fill=RIM)
    return img


def seven() -> Image.Image:
    img, d = base()
    f = _font(160)
    text = "7"
    bbox = d.textbbox((0, 0), text, font=f)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    d.text(((SIZE - tw) // 2, (SIZE - th) // 2 - 30), text,
           fill=(220, 30, 40), font=f, stroke_width=4, stroke_fill=RIM)
    return img


def diamond() -> Image.Image:
    img, d = base()
    # diamond shape
    pts = [(SIZE // 2, 50), (210, SIZE // 2), (SIZE // 2, 210), (50, SIZE // 2)]
    d.polygon(pts, fill=(80, 200, 230), outline=RIM)
    # facets
    d.polygon([(SIZE // 2, 50), (130, 100), (50, SIZE // 2)],
              fill=(150, 230, 245))
    d.polygon([(SIZE // 2, 50), (130, 100), (210, SIZE // 2)],
              fill=(110, 215, 240))
    return img


def wild() -> Image.Image:
    img, d = base()
    # gold star
    import math
    cx, cy = SIZE // 2, SIZE // 2
    R, r = 90, 38
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = R if i % 2 == 0 else r
        pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
    d.polygon(pts, fill=(245, 200, 50), outline=RIM)
    f = _font(54)
    bbox = d.textbbox((0, 0), "W", font=f)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    d.text((cx - tw // 2, cy - th // 2 - 4), "W",
           fill=(120, 50, 0), font=f, stroke_width=2, stroke_fill=RIM)
    return img


SYMBOLS = {
    "cherry": cherry,
    "lemon": lemon,
    "orange": orange,
    "bell": bell,
    "bar1": bar1,
    "bar2": bar2,
    "bar3": bar3,
    "seven": seven,
    "diamond": diamond,
    "wild": wild,
}


def main() -> None:
    for name, fn in SYMBOLS.items():
        out = os.path.join(DST, f"{name}.png")
        fn().save(out)
        print(f"wrote {out}")


if __name__ == "__main__":
    main()
